#!/bin/bash

zip -r insightly-extension.zip . -x "*.git*" "*.DS_Store" "*.idea*"
